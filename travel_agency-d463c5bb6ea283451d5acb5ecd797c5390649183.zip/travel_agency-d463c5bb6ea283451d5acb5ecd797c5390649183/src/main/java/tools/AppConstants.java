package main.java.tools;

public class AppConstants {
    public static final String APP_NAME = "Travel Management System";
    public static final String[] DEVELOPERS = { "Eve", "Ivie", "Wilton" };
}
